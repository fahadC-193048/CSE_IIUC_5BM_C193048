 <?php 
  // echo "<pre>" ;
  // print_r($_POST);
  $stid       = $_POST['studentId'] ;
  $stname     = $_POST['studentName'] ;
  $fathername = $_POST['fatherName'] ;
  $dob        = $_POST['datepicker'] ;
  $religion   = $_POST['religion'] ;
  $sec        = $_POST['section'] ;
  $dept       = $_POST['department'];
  $gen        = $_POST['gender'];
  

  $connect = mysqli_connect("localhost","root","","studentdata");
  mysqli_query($connect,"INSERT INTO reginfo(id,name,fathername,dob,religion,sec,dept,gender) values('$stid','$stname','$fathername','$dob','$religion','$sec','$dept','$gen')");
  echo('Insert Successful');
?>