-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2022 at 08:12 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentdata`
--

-- --------------------------------------------------------

--
-- Table structure for table `reginfo`
--

CREATE TABLE `reginfo` (
  `id` varchar(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `fathername` varchar(30) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `religion` varchar(15) NOT NULL,
  `sec` varchar(5) NOT NULL,
  `dept` varchar(10) NOT NULL,
  `regtime` timestamp NOT NULL DEFAULT current_timestamp(),
  `gender` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reginfo`
--

INSERT INTO `reginfo` (`id`, `name`, `fathername`, `dob`, `religion`, `sec`, `dept`, `regtime`, `gender`) VALUES
('C193050', 'rimon', 'joynal', '05/17/2000', 'islam', '5AM', 'EEE', '2022-05-16 18:21:26', 'male'),
('C193051', 'fahim', 'joynal', '05/17/2000', 'islam', '5AM', 'EB', '2022-05-16 18:34:22', 'female'),
('C193052', 'fahim', 'xyz', '05/31/2022', 'islam', '5AM', 'CSE', '2022-05-16 18:37:31', 'male'),
('C193055', 'sfdsdg', 'xyz', '05/10/2022', 'fgfh', 'yhjh', 'EB', '2022-05-16 19:18:26', 'other'),
('C193075', 'rahat', 'xyz', '05/03/2022', 'islam', '5BM', 'CSE', '2022-05-23 17:21:33', 'male'),
('C1930777', 'fahad', 'xyz', '05/25/2022', 'islam', '5BM', 'CSE', '2022-05-23 18:10:53', 'male'),
('C193079', 'tonmoy', 'xyz', '05/06/2022', 'islam', '3BM', 'CSE', '2022-05-23 17:14:18', 'male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reginfo`
--
ALTER TABLE `reginfo`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
