<?php
session_start();
include 'connection.php';
 
$query=mysqli_query($connection,"SELECT * FROM  reginfo");
 
if($_SESSION['success']=='success')
{
    echo 'Data has been saved successfully';
    $_SESSION['success']='';
}
?>
<table border="1" style="width:70%">
<tr>
    <td>#</td>
    <td>Student ID</td>
    <td>Student Name</td>
    <td>Father Name</td>
    <td>date of Birth</td>
    <td>Religion</td>
    <td>Section</td>
    <td>Department</td>
    <td>Gender</td>
    <td>Delete</td>
    <td>Edit</td>
</tr>
 
<?php
$serial=1;
while($row=mysqli_fetch_array($query))
{
$id=$row['id'];
    ?>
    <tr>
    <td><?php echo $serial++?></td>
    <td><?php echo $row['id']?></td>
    <td><?php echo $row['name']?></td>
    <td><?php echo $row['fathername']?></td>
    <td><?php echo $row['dob']?></td>
    <td><?php echo $row['religion']?></td>
    <td><?php echo $row['sec']?></td>
    <td><?php echo $row['dept']?></td>
    <td><?php echo $row['gender']?></td>

    <td>
        <a href="delete.php?id=<?php echo $id?>">Delete</a>
    </td>
    <td>
        <a href="edit.php?id=<?php echo $id?>">Edit</a>
    </td>
</tr>
    <?php
}
?>
</table>