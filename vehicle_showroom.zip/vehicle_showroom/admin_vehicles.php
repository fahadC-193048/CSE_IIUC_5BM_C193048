<?php

@include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:login.php');
};

if(isset($_POST['add_vehicle'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $price = $_POST['price'];
   $price = filter_var($price, FILTER_SANITIZE_STRING);
   $category = $_POST['category'];
   $category = filter_var($category, FILTER_SANITIZE_STRING);
   $details = $_POST['details'];
   $details = filter_var($details, FILTER_SANITIZE_STRING);

   $image = $_FILES['image']['name'];
   $image = filter_var($image, FILTER_SANITIZE_STRING);
   $image_size = $_FILES['image']['size'];
   $image_tmp_name = $_FILES['image']['tmp_name'];
   $image_folder = 'uploaded_img/'.$image;
   $brand = "";
   $sql= (" SELECT * FROM vehicles WHERE name='$name' ");
   $query=$connect->query($sql);
  
   if(mysqli_num_rows($query)>0){
      $message[] = 'vehicle name already exist!';
   }else{

      $insert_vehicles=mysqli_query($connect,"INSERT INTO vehicles(name, category, details,price, image,brand) 
      VALUES('$name','$category','$details', '$price' ,'$image','$brand')");


      if($insert_vehicles){
         if($image_size > 2000000){
            $message[] = 'image size is too large!';
         }else{
            move_uploaded_file($image_tmp_name, $image_folder);
            $message[] = 'new Vehicle added!';
         }

      }

   }

};

if(isset($_GET['delete'])){

   $delete_id = $_GET['delete'];
  
   $sql= (" SELECT image FROM vehicles WHERE id='$delete_id'");
   $query=$connect->query($sql);
   $fetch_delete_image=mysqli_fetch_assoc($query);
   unlink('uploaded_img/'.$fetch_delete_image['image']);

   $delete_vehicles=mysqli_query($connect,"DELETE  FROM vehicles WHERE id='$delete_id'");

   $delete_wishlist = mysqli_query($connect,"DELETE  FROM wishlist WHERE pid='$delete_id'");
   
   $delete_cart =  mysqli_query($connect,"DELETE  FROM cart WHERE pid='$delete_id'");
  
   header('location:admin_vehicles.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>vehicles</title>


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">


    <link rel="stylesheet" href="css/admin_style.css">

</head>

<body>

    <?php include 'admin_header.php'; ?>

    <section class="add-vehicles">

        <h1 class="title">add new Vehicle</h1>

        <form action="" method="POST" enctype="multipart/form-data">
            <div class="flex">
                <div class="inputBox">
                    <input type="text" name="name" class="box" required placeholder="Enter Vehicle name">
                    <select name="category" class="box" required>
                        <option value="" selected disabled>select category</option>
                        <option value="cars">cars</option>
                        <option value="motorbikes">motorbikes</option>
                        <option value="cycles">cycles</option>
                    </select>
                </div>
                <div class="inputBox">
                    <input type="number" min="0" name="price" class="box" required placeholder="Enter Vehicle price">
                    <input type="file" name="image" required class="box" accept="image/jpg, image/jpeg, image/png">
                </div>
            </div>
            <textarea name="details" class="box" required placeholder="Enter Vehicle details" cols="30"
                rows="10"></textarea>
            <input type="submit" class="btn" value="add vehicle" name="add_vehicle">
        </form>

    </section>

    <section class="show-vehicles">

        <h1 class="title">vehicles added</h1>

        <div class="box-container">

            <?php
     
      $sql= (" SELECT * FROM vehicles ");
      $query=$connect->query($sql);

      if(mysqli_num_rows($query) > 0){
         while($fetch_vehicles = mysqli_fetch_array($query)){  

   ?>
            <div class="box">
                <img src="uploaded_img/<?= $fetch_vehicles['image']; ?>" alt="">
                <div class="name"><?= $fetch_vehicles['name']; ?></div>
                <div class="cat"><?= $fetch_vehicles['category']; ?></div>
                <div class="name">Tk   <?= $fetch_vehicles['price']; ?>/-</div>
                <div class="details"><?= $fetch_vehicles['details']; ?></div>
                <div class="flex-btn">
                    <a href="admin_update_vehicle.php?update=<?= $fetch_vehicles['id']; ?>" class="blue-btn">update</a>
                    <a href="admin_vehicles.php?delete=<?= $fetch_vehicles['id']; ?>" class="delete-btn"
                        onclick="return confirm('delete this Vehicle?');">delete</a>
                </div>
            </div>
            <?php
      }
   }else{
      echo '<p class="empty">now vehicles added yet!</p>';
   }
   ?>

        </div>

    </section>

    <script src="js/script.js"></script>

</body>

</html>