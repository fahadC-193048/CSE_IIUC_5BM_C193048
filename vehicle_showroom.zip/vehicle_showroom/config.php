<?php
     $connect =mysqli_connect("localhost","root","","showroom_db");
?>